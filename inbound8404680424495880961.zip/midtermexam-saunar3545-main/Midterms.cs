﻿//midterms
namespace Midterms
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("10 Players:");
            Console.WriteLine();

            string[] Player = { "Player1", "Player2", "Player3", "Player4", "Player5", "Player6", "Player7", "Player8", "Player9", "Player10" };


            for (int i = 0; i < Player.Length; i++) 
            {

                string userPlay;
                string userInput;


                Console.WriteLine(Player[i]);
                userPlay = Player[i].Trim();

                Console.WriteLine("A.Play " + "B.Skip");
                userInput = Player[i].Trim();
                userPlay = Console.ReadLine();

                {
                    Console.WriteLine("Options:");
                    Console.WriteLine();
                }

                Console.WriteLine("A.Attack");
                Console.WriteLine("B.Shield");
                Console.WriteLine("C.Weapon");
                userInput = Console.ReadLine();
                
            }                 
     

        }


    }


}
