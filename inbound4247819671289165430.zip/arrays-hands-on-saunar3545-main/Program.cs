﻿using System;

namespace Weeksss
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] days = { "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat", "Sun" };

            foreach (string day in days)
            {
                Console.WriteLine(day);


                Console.WriteLine("Enter number of subjects: ");
                int subjects = Convert.ToInt32(Console.ReadLine());

                int[] grades = new int[subjects];

                for (int i = 0; i < grades.Length; i++)
                {
                    Console.WriteLine("Enter the grade for subject " + (i + 1) + ":");
                    grades[i] = Convert.ToInt32(Console.ReadLine());
                }

                Console.WriteLine();
                Console.WriteLine();
                for (int i = 0; i < grades.Length; i++)
                {
                    Console.WriteLine(grades[i]);
                }

            }
        }
    }
}

                
            
        
    

